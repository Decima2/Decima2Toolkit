# decima2/__init__.py
from .model.explanation.explanation_generation import model_feature_importance